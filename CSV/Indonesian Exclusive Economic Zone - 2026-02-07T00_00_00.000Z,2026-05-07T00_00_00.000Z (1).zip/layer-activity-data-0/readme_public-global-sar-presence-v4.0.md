
## SAR with Neural classification dataset
Downloaded date: May 10 2026 05:46 UTC
API Dataset versions: public-global-sar-presence:v4.0

### Description
<h2>Overview</h2>
<p>Satellite synthetic aperture radar (SAR) is a spaceborne radar imaging system that can detect at-sea vessels and structures in any weather conditions. Microwave pulses are transmitted by a satellite-based antenna towards the Earth surface. The microwave energy scattered back to the spacecraft is then measured and integrated to form a “backscatter” image. The SAR image contains rich information about the different objects on the water, such as their size, orientation and texture. SAR imaging systems overcome most weather conditions and illumination levels, including clouds or rain due to the cloud penetrating property of microwaves, and daylight or darkness due to radar being an “active” sensor (it shoots and records back its own energy). SAR gives an advantage over some other “passive” satellite sensors, such as electro-optical imagery, consisting of a satellite-based camera recording the sunlight/infrared radiation reflected from/emitted by objects on the ground. This latter method can be confounded by cloud cover, haze, weather events and seasonal darkness at high latitudes.</p>
<h2>Use cases</h2>
<ul>
 <li>Monitor vessel presence (both fishing and non-fishing) in areas of interest such as marine protected areas (MPAs), exclusive economic zones (EEZs), inshore exclusion zones (IEZs) and Regional Fisheries Management Organisations (RFMOs).</li>
 <li>Assess presence of vessels that don’t show up on cooperative tracking systems—including automatic identification system (AIS) and vessel monitoring system (VMS)—near vulnerable marine ecosystems and essential fish habitats.</li>
</ul>
<h2>Limitations</h2>
<ul>
 <li><b>Sentinel-1 SAR data does not sample most of the open ocean.</b></li>
 <ul>
 <li>Sentinel-1 does not sample most of the open ocean. However, the vast majority of industrial activity is close to shore. Also, farther from shore, more fishing vessels use AIS (60-90%), far more than the average for all fishing vessels (about 25%). Thus, for most of the world, our detection data complemented by AIS will capture the vast majority of human activity in the global ocean.</li>
 </ul>
 <li><b>False positives can be produced from image artifacts (noise).</b></li>
 <li><b>We do not provide detections of vessels 1 kilometer from shore as it’s difficult to accurately map where the shoreline begins.</b></li>
 <ul>
 <li>We do not include objects within 1 km of shore because of ambiguous coastlines and rocks. Nor do we include objects in much of the Arctic and Antarctic, where sea ice can create too many false positives; in both regions, however, vessel traffic is either very low (Antarctic) or in countries that have a high adoption of AIS (northern European or northern North American countries). The bulk of industrial activities occur several kilometers from shore, such as fishing along the continental shelf break, ocean transport over shipping lanes, and offshore development on medium-to-large oil rigs and wind farms. Also, much of the vessel activity within 1 km of shore is by smaller boats such as pleasure crafts.</li>
 </ul>
 <li><b>Vessel detection by SAR imagery is limited primarily by the resolution of the images (~20 m in the case of Sentinel-1 IW GRD products).</b></li>
 <ul>
 <li>As a result, we miss most vessels under 15 m in length, although an object smaller than a pixel can still be seen if it is a strong reflector, such as a vessel made of metal rather than wood or fiberglass. Especially for smaller vessels (25 m), detection also depends on wind speed and the state of the ocean, as a rougher sea surface will produce higher backscatter, making it difficult to separate a small target from the sea clutter. Conversely, the higher the radar incidence angle, the higher the probability of detection, as less backscatter from the background will be received by the antenna. The vessel orientation relative to the satellite antenna also matters, as a vessel perpendicular to the radar line of sight will have a larger backscatter cross section, increasing the probability of being detected.</li>
 </ul>
 <li><b>Vessel length estimates are limited by the quality of ground truth data</b></li>
 <ul>
 <li>Although we selected only high-confidence AIS-SAR matches to construct our training data, we found that some AIS records contained an incorrectly reported length. These errors, however, resulted in only a small fraction of imprecise training labels, and deep learning models can accommodate some noise in the training data.</li>
 </ul>
 <li><b>Not all geographies are covered equally</b></li>
 <ul>
 <li>Our fishing classification may be less accurate in certain regions. In areas of high traffic from pleasure crafts and other service boats, such as near cities in some countries and in the fjords of Norway and Iceland, some of these smaller craft might be misclassified as fishing vessels. Conversely, some misclassification of fishing vessels as non-fishing vessels is expected in areas where all activity is not publicly shared. More importantly, however, is that many industrial fishing vessels are between 10 and 20 meters in length, and the detection capability of our model falls off quickly within these lengths. As a result, the total number of industrial fishing vessels is likely significantly higher than what we detect.</li>
 <li>Our data likely underestimates the concentration of fishing in some regions, where we see areas of vessel activity being "cut off" by the edge of the Sentinel-1 footprint and we miss very small vessels (e.g., most artisanal fishing) that are less likely to carry AIS devices.</li>
 </ul>
</ul>
<h2>Methods</h2>
<h3>SAR imagery</h3>
<p>We use SAR imagery from the Copernicus Sentinel-1 mission of the European Space Agency (ESA) [1]. The images are sourced from two satellites (S1A and S1B up until December 2021 when S1B stopped operating, and S1A only from 2022 onward) that orbit 180 degrees out of phase with each other in a polar, sun-synchronous orbit. Each satellite has a repeat-cycle of 12 days, so that together they provide a global mapping of coastal waters around the world approximately every six days for the period that both were operating. The number of images per location, however, varies greatly depending on mission priorities, latitude, and degree of overlap between adjacent satellite passes. Spatial coverage also varies over time [2]. Our data consist of dual-polarization images (VH and VV) from the Interferometric Wide (IW) swath mode, with a resolution of about 20 m.</p>
<p>[1]
 <a target="_blank" href="https://sedas.satapps.org/wp-content/uploads/2015/07/Sentinel-1_User_Handbook.pdf">
 <span style="color:rgb(0, 0, 0);">https://sedas.satapps.org/wp-content/uploads/2015/07/Sentinel-1_User_Handbook.pdf</span>
 </a>
</p>
<p>[2]<a target="_blank" href="https://sentinels.copernicus.eu/web/sentinel/missions/sentinel-1/observation-scenario">
 <span style="color:rgb(0, 0, 0);"></span>
 <span style="color:rgb(0, 0, 0);">https://sentinels.copernicus.eu/web/sentinel/missions/sentinel-1/observation-scenario</span>
 </a>
</p>
<h3>Detection footprints</h3>
<p>Detection footprints are areas within each satellite scan (or scene) that our system uses to perform detections. These filters help to keep relevant detections and exclude data that may be inaccurate. Detection footprints are smaller than the total scene as they exclude any land areas and islands, and exclude a 500 meter buffer from the boundaries of the scene and a 1 kilometer buffer from shorelines.</p>
<h3>Filtering</h3>
<p>GFW has post-processed the SAR detections to reduce noise (false positives), remove offshore infrastructure from this layer focused on vessels, and exclude areas with sea ice at high latitudes.</p>
<h3>Vessel detection by SAR</h3>
<p>Detecting vessels with SAR is based on an known as Constant False Alarm Rate (CFAR), a threshold algorithm used for anomaly detection in radar imagery. This algorithm is designed to search for pixel values that are unusually bright (the targets) compared to those in the surrounding area (the sea clutter). This method sets a threshold based on the pixel values of the local background (within a window), scanning the whole image pixel-by-pixel. Pixel values above the threshold constitute an anomaly and are likely to be samples from a target, and therefore are included as a detection.</p>
<h3>Vessel presence and length estimation</h3>
<p>To estimate the length of every detected object and also to identify when our CFAR algorithm made false detections, we designed a deep convolutional neural network (ConvNet) based on the modern ResNet (Residual Networks) architecture. This single-input/multi-output ConvNet takes dual-band SAR image tiles of 80 by 80 pixels as input, and outputs the probability of object presence (known as a “binary classification task”) and the estimated length of the object (known as a “regression task”).</p>
<h3>Fishing and non-fishing classification</h3>
<p>To identify whether a detected vessel was a fishing or non-fishing vessel we use a machine learning model. For this classification task we used a ConvNeXt architecture modified to process the following two inputs: the estimated length of the vessel from SAR (a scalar quantity) and a stack of environmental rasters centered at the vessel’s location (a multi-channel image). This multi-input-mixed-data/single-output model passes the raster stack (11 channels) through a series of convolutional layers and combines the resulting feature maps with the vessel length value to perform a binary classification: fishing or non-fishing.&nbsp;</p>
<p>The environmental layers used to differentiate between fishing and non-fishing include:</p>
<ol>
 <li>vessel density (based on SAR)</li>
 <li>average vessel length (based on SAR)</li>
 <li>bathymetry</li>
 <li>distance from port</li>
 <li>hours of non-fishing vessel presence, under 50 m (from AIS)</li>
 <li>hours of non-fishing vessel presence, over 50 m (from AIS)</li>
 <li>average surface temperature</li>
 <li>average current speed</li>
 <li>standard deviation of daily temperature</li>
 <li>standard deviation of daily current speed</li>
 <li>average chlorophyll</li>
</ol>
<h3>AIS matching and vessel identity</h3>
<p>AIS data can reveal the identity of vessels, their owners and corporations, and fishing activity. Not all vessels, however, are required to use AIS devices, as regulations vary by country, vessel size, and activity. Vessels engaged in illicit activities can also turn off their AIS transponders or manipulate the locations they broadcast. Also, large “blind spots” along coastal waters arise from nations that restrict access to AIS data that are captured by terrestrial receptors instead of satellites or from poor reception due to high vessel density and low-quality AIS devices. Unmatched SAR detections therefore provide the missing information about vessel traffic in the ocean.</p>
<h3>SAR and AIS matching</h3>
<p>Matching SAR detections to vessels’ GPS coordinates (from the automatic identification system (AIS) is challenging because the timestamp of the SAR images and AIS records do not coincide, and a single AIS message can potentially match to multiple vessels appearing in the image, and vice versa. To determine the likelihood that a vessel broadcasting AIS corresponded to a specific SAR detection, we followed a matching approach based on probability rasters of where a vessel is likely to be minutes before and after an AIS position was recorded. These rasters were developed from one year of global AIS data from the Global Fishing Watch pipeline which uses Spire Global and Orbcomm sources of satellite data, including roughly 10 billion vessel positions, and computed for six different vessel classes, considering six different speeds and 36 time intervals. So we obtain the likely position of a vessel that could match a SAR detection based on the vessel class, speed and time interval.</p>
<h3>AIS matching and vessel identity</h3>
<p>Automatic identification system (AIS) data can reveal the identity of vessels, their owners and corporations, and fishing activity. Not all vessels, however, are required to use AIS devices, as regulations vary by country, vessel size, and activity. Vessels engaged in illicit activities can also turn off their AIS transponders or manipulate the locations they broadcast. Also, large “blind spots” along coastal waters arise from nations that restrict access to AIS data that are captured by terrestrial receptors instead of satellites or from poor reception due to high vessel density and low-quality AIS devices. Unmatched SAR detections therefore provide the missing information about vessel traffic in the ocean.</p>
<h2>Resources, code and other notes</h2>
<p>All code developed in this study for SAR detection, deep learning models, and analyses is open source and freely available at
 <a target="_blank" href="https://github.com/GlobalFishingWatch/paper-industrial-activity">
 <span style="color:rgb(0, 0, 0);">https://github.com/GlobalFishingWatch/paper-industrial-activity</span>
 </a>.
</p>
<h2>Source data and citations</h2>
<p>All vessel data are freely available through the Global Fishing Watch data portal at
 <a target="_blank" href="https://globalfishingwatch.org">
 <span style="color:rgb(0, 0, 0);">https://globalfishingwatch.org</span>
 </a>. All data to reproduce our supporting scientific paper can be downloaded from
 <a target="_blank" href="https://doi.org/10.5281/zenodo.8256932">
 <span style="color:rgb(0, 0, 0);">https://doi.org/10.6084/m9.figshare.24309475</span>
 </a>
 (statistical analyses and figures) and
 <a target="_blank" href="https://doi.org/10.6084/m9.figshare.24309469">
 <span style="color:rgb(0, 0, 0);">https://doi.org/10.6084/m9.figshare.24309469</span>
 </a>
 (model training and evaluation).
</p>
<h2>License</h2>
<p>Non-Commercial Use Only. The Site and the Services are provided for Non-Commercial use only in accordance with the CC BY-NC 4.0 license. If you would like to use the Site and/or the Services for commercial purposes, please contact us.

Filters:  timestamp >= parseDateTimeBestEffort('2026-02-07T00:00:00.000Z') and timestamp < parseDateTimeBestEffort('2026-05-07T00:00:00.000Z')
Group by: flagAndGearType
Temporal resolution: monthly (data is grouped by flagAndGearType and summarized by month)
Spatial aggregation: false
 Resolution: low (10th degree resolution)

### Columns

* Lat: the latitude of the center of the grid cell, in 10ths or 100th of a degree (depending on spatial resolution selection) 
* Lon: the longitude of the center of the grid cell, in 10ths or 100th of a degree (depending on spatial resolution selection)
* Time Range: The data format depends on the temporal resolution, for monthly (YYYY-MM), for daily (YYYY-MM-DD), for yearly (YYYY) and for entire the date-range query param value.
* flagAndGearType: flagAndGearType.
* Vessel IDs: Number of different vessel ids.

flagAndGearType.
* Detections: Detections present in the grid cell over the selected time range


## License
Unless otherwise stated, Global Fishing Watch data is licensed under a Creative Commons Attribution-ShareAlike 4.0 International license and code under an Apache 2.0 license.

For additional information about:
these results, see the associated journal article: D.A. Kroodsma, J. Mayorga, T. Hochberg, N.A. Miller, K. Boerder, F. Ferretti, A. Wilson, B. Bergman, T.D. White, B.A. Block, P. Woods, B. Sullivan, C. Costello, and B. Worm. "Tracking the global footprint of fisheries." Science 361.6378 (2018). http://science.sciencemag.org/content/359/6378/904 
Data caveats and details: https://globalfishingwatch.org/dataset-and-code-fishing-effort/ 

## Data Versioning

The AIS data used by Global Fishing Watch are updated daily and periodically revised following occasional interruptions in our AIS feed.  Additionally, we are continuously working to improve our technology to most accurately classify and track vessels globally using AIS. Therefore, data downloaded from our map is subject to change over time. There may also be slight differences between data downloaded from the Global Fishing Watch map and the static datasets that are available on the data download page (https://globalfishingwatch.org/data-download/datasets/public-fishing-effort). Every effort is made to ensure these data are as similar as possible, however the intention of the downloadable datasets are slightly different. The static datasets have been thoroughly reviewed and use a specific versioning in order to be reproducible for in-depth research. The data provided through the Global Fishing Watch map is generated using 4wings experimental technology. The map uses the latest versioning of our data available, along with any improvements identified in our algorithms, and is updated every single day. We will continue to improve our documentation on versioning of our different downloadable data, and will notify users of these updates. 

## Suggested Citation

Global Fishing Watch. 2022, updated daily. Vessel presence and apparent fishing effort v20201001, [Feb 07 2026 00:00 UTC May 07 2026 00:00 UTC]. Data set accessed 2026-05-10 at https://globalfishingwatch.org/map
	
